
// CSF module to manage properties
// properties are stored in a file as JSON string

var fs = require('fs');

// each module instantiates its own properties
// modName is the module name
// opts is an optional object which can contain:
// - options.defaults: some defaults properties
// - filename: the full path to the file to use to read/write properties
// - autoSave: boolean to activate auto-saving (true by default)
// logger is a csf logger
function Properties(modName, logger, opts) {
    logger.log('properties - new instance for module "' + modName + '"');
    var moduleName = modName;
    
    var options = {
            defaults: {},
            filename: null,
            autoSave: true
        }.extend(opts || {});
    
    var properties = {}.extend(options.defaults);
    
    var self = this;
    
    // create routes to GET or POST properties
    this.createRoutes = function(app) {
        
        logger.log('properties - create routes for module ' + moduleName);
        
        // GET api to retrieve a property or all properties
        app.get('/' + moduleName + '/properties/:key?', function(req, res) {
           
            key = req.params.key;
           
            if (key) {
                if (properties[key]) {
                    res.send(properties[key], { 'Content-Type': 'application/json' });
                    return;
                }
                
                // not found
                res.send('unknown property ' + key , 404);
                return;
            }
            
            //no key specified, return all properties
            res.send(properties);
        });
        
        // POST api to update a property
        app.post('/' + moduleName + '/properties/:key', function(req, res) {
           
            key = req.params.key;
            logger.log(true, "properties - post property value: " + req.body);
            value = req.body;
            
            properties[key] = value;
            
            if (options.autoSave) {
                self.save();   
             }
            
            res.send('', {'Uri': '/' + moduleName + '/properties/' + key}, 201);
        });
        
    } // end of createRoutes
    
    // load properties from file
    this.loadSync = function() {
        
        if (!options.filename) {
            logger.log(true, "properties - no filename to read properties");
            return;
        }
        
        try {
            json = fs.readFileSync(options.filename);
            // load file content into properties object
            logger.log(true, "properties - loaded properties from " + options.filename);
            
            data = JSON.parse(json);
            if (data) {
                // extend default properties with file data
                properties = options.defaults.extend(data);
            }
            else {
                logger.log(true, "properties - cannot find properties in " + options.filename);
            }
        }
        catch (e) {
            logger.log("properties - cannot load properties: " + e.message);
        }
    } // end of loadSync
    
    this.save = function() {
        
        if (!options.filename) {
            logger.log("properties - no filename to save properties");
            return;
        }
        
        fs.writeFile(options.filename, JSON.stringify(properties), function(err) {
            if (err) {
               logger.log("properties - cannot save properties: " + err);
    	    }
    	    else {
    	       logger.log(true, "properties - saved properties to " + options.filename);
    	    }
        });
    } // end of save
    
    this.get = function(key) {
        return properties[key];
    }
    
   	this.set = function(key, value) {
        properties[key] = value;
    }
    
    this.setValues = function(values) {
    	for (var key in values) {
    		self.set(key, values[key]);
    	}
    }
    
    /*
    if (options.defaults) {
    	// save default properties
    	self.save();
    }
    else {
	    // load properties from file if any
    	self.loadSync();
    }
    */
    
    return self;
};

exports.Properties = Properties;

exports.createProperties = function(modName, logger, opts) {
	return new Properties(modName, logger, opts);
}

