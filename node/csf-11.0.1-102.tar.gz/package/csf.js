
var util = require('util');

var logger = require('csf/logger').createLogger('csf');

// define the extend method
// see http://stackoverflow.com/questions/5055746/cloning-an-object-in-node-js
Object.defineProperty(Object.prototype, "extend", {
    enumerable: false,
    value: function(from) {
        var props = Object.getOwnPropertyNames(from);
        var dest = this;
        props.forEach(function(name) {
            if (name in dest) {
                var destination = Object.getOwnPropertyDescriptor(from, name);
                Object.defineProperty(dest, name, destination);
            }
        });
        return this;
    }
});

var version = '11.0.1-102';
if (require.main === module) {
    var pkg = require('./package.json');
    version = pkg.version;
}

logger.log('running node.csf version ' + version);
logger.log('running node.js version ' + process.version);

// default configuration
var config = {
	port: 1789,
	env: 'production',
	verbose: false,
	jsonp: true,
	'socket.io': null,
	cors: {},
	https: null,
	staticDirs: [],
	modules: {}
};

// module to access file system
var fs = require('fs');
var path = require('path');

var configFile = './node.csf.cfg';

if (process.argv.length >= 3) {
	configFile = process.argv[2];
}

// load config from local node.cwc.cfg
try {
	logger.log('reading configuration from ' + configFile);
	json = fs.readFileSync(configFile);
	
	data = JSON.parse(json);
	if (data) {
		// extend default properties with file data
		config.extend(data);
	}
}
catch (e) {
	logger.log('cannot read ' + configFile);
	logger.log(true, e);
	logger.log("no configuration specified, use 'node csf.js <config-file>'");
}

// load the Express JS web framework
// http://expressjs.com
var express = require('express');
logger.log('loaded express web framework version ' + express.version);

// create the Express application and the http server
var app = express();
var server = null;
if (config.https && config.https.enabled == true) {
  logger.log('creating https secure server');
  server = require('https').createServer({
    key: fs.readFileSync(config.https.key),
    cert: fs.readFileSync(config.https.cert)
  },
  app);
}
else {
  logger.log('creating http server');
  server = require('http').createServer(app);
}
logger.log(true, 'server created');

// set application environment
app.set('env', config.env);
logger.log(true, 'application environment is ' + app.set('env'));

if (config.jsonp) {
	// set JSONP support
	app.set('jsonp callback', config.jsonp);
	logger.log('JSONP support ' + app.set('jsonp callback'));
}

// configure the application
app.configure(function() {
	logger.log('configure common');
    app.use(express.methodOverride());
    app.use(express.bodyParser({
    	uploadDir: '/var/csf/uploads'
    }));
    
    if (config.cors) {
	    var CORS = require('connect-xcors');
	    app.use(CORS(config.cors));
	    logger.log('use CORS');
    }
	
	for (i=0; i<config.staticDirs.length; i++) {
		logger.log('serve static ' + config.staticDirs[i]);
		app.use(express.static(config.staticDirs[i]));
	}
});

// specific configuration to development environnment
app.configure('development', function() {
   logger.log('configure development environment');
   app.use(express.errorHandler({ dumpExceptions: true, showStack: true }));
   app.use(express.logger({ format: ':date :method :url :status'}));
});

// specific configuration to beta environnment
app.configure('beta', function() {
   logger.log('configure beta environment');
   app.use(express.errorHandler({ dumpExceptions: true, showStack: true }));
});

// specific configuration to production environment
app.configure('production', function() {
   logger.log('configure production environment');
   app.use(express.errorHandler()); 
});

var io = null;
var cfgio = config['socket.io'];
if (cfgio) {
	if (cfgio.enabled == false) {
		logger.log('socket.io is not enabled');
	}
	else {
		io = require('socket.io').listen(server, {
			'log level': cfgio['log level'],
			'logger': {
				log: function(type) { logger.log('socket.io - ' + util.toArray(arguments).slice(1)); },
				error: function(msg) { logger.log('socket.io - ' + msg); },
				warn: function(msg) { logger.log('socket.io - ' + msg); },
				info: function(msg) { logger.log('socket.io - ' + msg); },
				debug: function(msg) { logger.log(true, 'socket.io - ' + msg); }
			}
		});
	}
}

// always load hello module
if (!config.modules.hello) {
	config.modules.hello = {};
}

// load modules
var moduleNames = [];

for (var module in config.modules) {
	if (config.modules.hasOwnProperty(module)) {
		try {
			logger.log('load module ' + module);
			var moduleConfig = config.modules[module];
			
			if (typeof moduleConfig === "string") {
				// file name
				var moduleConfigFile = path.join(path.dirname(fs.realpathSync(configFile)), moduleConfig);
				
				logger.log('read ' + module + ' configuration from ' + moduleConfigFile);
				var data = JSON.parse(fs.readFileSync(moduleConfigFile));

           		if (data) {
                	moduleConfig = data;
           		}
            	else {
                	throw "cannot find configuration from file " + moduleConfig;
            	}
			}
			
			if (typeof moduleConfig !== "object") {
				throw 'wrong type of configuration';
			}
			moduleConfig.verbose = moduleConfig.verbose || config.verbose;
			
			if (moduleConfig.enabled == false) {
				logger.log('module ' + module + ' is not enabled');
			}
			else {
				require('csf/' + module).initialize(app, moduleConfig, io);
			
				logger.log('loaded module ' + module);
				moduleNames.push(module);
			}
		}
		catch (e) {
			logger.log('cannot load module ' + module);
			logger.log(e); 
		}
	}
}

// a route so clients can know what modules are loaded
app.get('/modules', function(req, res) {
	res.send(modules, { 'Content-Type': 'application/json' });
});

logger.log('listen on port ' + config.port);
server.listen(config.port);

logger.log('ready');
