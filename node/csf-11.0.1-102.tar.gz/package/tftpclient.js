
/*******************************************************************
 * A basic TFTP client to read a remote file using the TFTP protocol
 * 
 * See RFC1350:
 * http://tools.ietf.org/html/rfc1350
 * 
 *******************************************************************/

var util = require('util');

var dgram = require('dgram');

var OperationCode = {
    ReadRequest: 1,
    WriteRequest: 2,
    Data: 3,
    Ack: 4,
    Error: 5
};

// transfer mode ('octet' by default)
var Mode = {
    NetAscii: 'netascii',
    Octet: 'octet',
    Mail: 'mail'
};

exports.Mode = Mode;


/**
 * Read a remote file
 * settings is an object containing:
 *   - server: the remote TFTP server IP address or host name
 *   - filename: the path of the remote file to read
 *   - success: the success callback. Remote file content is passed as a Buffer
 *   - mode: the transfer mode (see exports.Mode), Mode.Octet by default
 *   - socketType: "udp6" or "udp4" (default)
 *   - error: optional error callback, which takes an error message as input
 *   - debug: print more debug statements to stderr (false by default)
 */
exports.readFile = function(settings) {

    if (!settings) {
        util.log('tftpclient - missing settings');
        return;
    }
    
    if (!settings.server) {
        msg = "missing settings.server (remote TFTP server IP address or host name)";
        util.log('tftpclient - ' + msg);
        
        if (settings.error) { settings.error(msg); }
        return;
    }
    
    if (!settings.filename) {
        msg = "missing settings.filename (remote file name)";
        util.log('tftpclient - ' + msg);
        
        if (settings.error) { settings.error(msg); }
        return;
    }
    
    if (!settings.mode) {
        settings.mode = Mode.Octet;   
    }
    
    if (settings.mode != Mode.Octet && settings.mode != Mode.NetAscii && settings.mode != Mode.Mail) {
        msg = "invalid transfer mode '" + settings.mode + "'";
        util.log('tftpclient - ' + msg);

        if (settings.error) { settings.error(msg); }
        return;
    }
    
    if (!settings.socketType) {
        settings.socketType = 'udp4';   
    }
    
    if (settings.socketType != 'udp4' && settings.socketType != 'udp6') {
        msg = "invalid socket type '" + settings.socketType +"'";
        util.log(msg);
        
        if (settings.error) { settings.error(msg); }
        return;
    }

    util.log("tftpclient - reading file " + settings.filename + " from server " + settings.server);

    var client = dgram.createSocket("udp4");
    
    var blocksLen = 0;
    var blocks = {};
    
    var closeTimeout = null;

    client.on("message", function (msg, rinfo) {
        
        // mandatory 4-byte header
        if (msg.length < 4) {
            err = "invalid message header (" + msg.length + " bytes)";
            util.log('tftpclient - ' + err);
            client.close();
            
            if (settings.error) { settings.error(err); }
            return;
        }
        
        // 2-byte operation code
        opCode = 256*msg[0] + msg[1];
        
        if (settings.debug) {
            util.debug("tftpclient - received message (" + msg.length + " bytes) opCode=" + opCode);
        }
        
        switch (opCode) {
        case OperationCode.Data: {
            // data message
            // 2 bytes     2 bytes      n bytes
            // ----------------------------------
            //| Opcode |   Block #  |   Data     |
            // ----------------------------------
            
            blockNum = 256*msg[2] + msg[3];
            
            // reply by acknowledging block number
            // 2 bytes     2 bytes
            // ---------------------
            //| Opcode |   Block #  |
            // ---------------------
            ack = new Buffer([0, OperationCode.Ack, msg[2], msg[3]]);
            client.send(ack, 0, ack.length, rinfo.port, rinfo.address);
            
            if (closeTimeout) {
                if (settings.debug) {
                    util.debug("tftpclient - ignoring data after termination");
                }
                break;
            }
            
            if (blocks[blockNum]) {
                if (settings.debug) {
                    util.debug("tftpclient - block " + blockNum + " already received");
                }
            }
            else {
                blocksLen += msg.length - 4;
                blocks[blockNum] = msg.slice(4, msg.length); // skip 4-byte header
            }
            
            if ((msg.length - 4) < 512) {
                if (settings.debug) {
                    util.debug('tftpclient - normal termination');
                }
                
                // allow 3 seconds before closing the connection
                closeTimeout = setTimeout(function() { closeTimeout = null; client.close(); }, 3000);
                
                if (settings.success) {
                    // concatenate blocks
                    var i = 1;
                    var buffer = new Buffer(blocksLen);
                    var bufferIndex = 0;
                    
                    while (blocks[i]) {
                        blocks[i].copy(buffer, bufferIndex, 0);
                        bufferIndex += blocks[1].length;
                        i++;
                    }
                    
                    util.log("tftpclient - concatenated " + (i-1) + " blocks into " + buffer.length + " bytes");
                    
                    settings.success(buffer);   
                }
                else {
                    util.log("tftpclient - no settings.success callback");   
                }
            }
            break;
        }
        
        case OperationCode.Ack: {
            // ack message
            //  2 bytes     2 bytes
            // ---------------------
            // | Opcode |   Block #  |
            // ---------------------
            if (settings.debug) {
                util.debug("tftpclient - unexpected ack while reading file, ignoring");
            }
            break;
        }
        
        case  OperationCode.Error: {
            // error message
            // 2 bytes     2 bytes      string    1 byte
            // -----------------------------------------
            //| Opcode |  ErrorCode |   ErrMsg   |   0  |
            // -----------------------------------------
            errCode = 256*msg[2] + msg[3];
            err = 'cannot retrieve file: ' + msg.toString('ascii', 4) + ' (' + errCode + ')';
            util.log('tftpclient - ' + err);
            client.close();
            
            if (settings.error) { settings.error(err); }
            break;
        }
        } // end of switch
    });


    client.on("listening", function () {
        if (settings.debug) {
            util.debug("tftpclient - listening " + client.address().address);
        }
      
        // build read request
        // 2 bytes     string    1 byte     string   1 byte
        // ------------------------------------------------
        //| Opcode |  Filename  |   0  |    Mode    |   0  |
        // ------------------------------------------------

        readReq = new Buffer(2 + Buffer.byteLength(settings.filename) + 1 + Buffer.byteLength(settings.mode) + 1);
      
        index = 0;
        readReq[index++] = 0;                             // 2 bytes for
        readReq[index++] = OperationCode.ReadRequest;     // read operation code
        index += readReq.write(settings.filename, index); // file name to read
        readReq[index++] = 0;                             // null separator
        index += readReq.write(settings.mode, index);     // mode
        readReq[index++] = 0;                             // last null byte
      
        client.send(readReq, 0, readReq.length, 69, settings.server,
            function (err, bytes) {
                if (err) {
                    util.log("tftpclient - cannot send: " + err);
                    if (settings.error) { settings.error(err); }
                }
                else {
                    if (settings.debug) { util.debug("tftpclient - wrote " + bytes + " bytes"); }
                }
            });
    });

    client.on("close", function() {
        if (settings.debug) { util.debug('tftpclient - socket closed'); }
    });
    
    // random local port - can bind return failure ?
    client.bind(12345);
    
} // end of readFile
