
var logger = require('csf/logger').createLogger('webcc');
var properties = require('csf/properties').createProperties('webcc', logger);

var sipcc = require('./sipcc');
var util = require('util');
var express = require('express');

// key is CUCM address, value is object with 'application' and/or 'directoryLookup' properties
// which are an array of
// { beginWith: String, numDigits: Number, digitsToRemove: Number, prefixWith: String }
var dialRules = {};

// beginning of testing
var cancelTimeout = null;
// end of testing

// initialize webcc module
exports.initialize = function(app, config, io) {
	logger.configure({
		verbose: config.verbose
	});
	
	if (!io) {
		logger.log('socket.io required');
		throw 'webcc: socket.io required';
	}
	
	logger.log(true, 'serve static ' + __dirname + '/www');
	app.use('/webcc/public', express.static(__dirname + '/www'));
	
	// start SIPCC
  	sipcc.start({
  		verbose: config.verbose,
  		log: function(isVerbose, msg, context) { logger.log(isVerbose, msg, context); }
  	});
  	
  	function shutdown() {
  	    try { sipcc.stop(); }
  	    catch(e) { logger.log('cannot stop sipcc: ' + e.message); }
  	}
  	
  	process.on('exit', function() {
  	    shutdown();
  	});
  	
  	process.on('SIGINT', function() {
  	    shutdown();
  	    process.exit(1);
  	});

    process.on('uncaughtException', function(err) {
        logger.log('uncaught exception: ' + err.message);
        shutdown();
        throw err;
    });

	io.of('/webcc/socket').on('connection', function(socket) {
		logger.log(true, 'new connection socket.id=' + socket.id);
		//logger.log(require('util').inspect(io.sockets.clients()));
		
		function _reset() {
			sipcc.session(socket.id, null);
		} // _reset
		
		socket.on('registerPhone', function(options, cb) {
			logger.log(true, 'registerPhone', options);
			
			if (!options) {
				return cb({ message: 'cannot registerPhone: no arguments' });
			}
			
			var settings = {
				cucm: options.cucm
			};
			
			// always authenticate the user
			var ccmcip = require('csf/ccmcipclient');
			    
			ccmcip.getDevices({
			    userName: options.user,
			    userPassword: new Buffer(options.password, 'base64').toString(),
			    ccmcipHost: options.cucm,
			    log: function(msg) { logger.log(true, msg); },
			    error: function() {
			        cb({ message: 'Authentication failure' });
			    },
			    success: function(devices) {
			        if (!options.device) {
			            // the application has not selected any device, return the available one(s)
    		            return cb(null, { availableDevices: devices });
    		        }
    		        
    		        // the application specified a device, check it is in the list of available ones
    		        var deviceName = options.device.name || options.device;
    		        var found = false;
    		        for (var i=0; i<devices.length; i++) {
    		            if (deviceName.toLowerCase() == devices[i].name.toLowerCase()) {
    		                found = true;
    		                break;
    		            }
    		        }
    		        
    		        if (!found) {
    		            return cb({ message: 'Device "' + deviceName + '" is not associated to user "' + options.user + '"' });
    		        }
    		        
    		        settings.device = deviceName;
			
                    retrieveDevice(settings.cucm, settings.device, function(error, deviceInfo) {
                        if (error) { return cb(error); }
                        
                        logger.log(true, 'retrieved device ' + settings.device + ' from cucm ' + settings.cucm);
                        logger.log(true, 'line=' + deviceInfo.line + ' displayName=' + deviceInfo.displayName);
                        
                        settings.log = function(msg, context) {
                            logger.log(true, msg, context);
                        };
                        settings.verbose = config.verbose;
                        settings.line = deviceInfo.line;
                        settings.contact = deviceInfo.contact;
                        settings.displayName = deviceInfo.displayName;
                        settings.processNodeName = deviceInfo.processNodeName;
                        settings.clientid = socket.id;
                        
                        logger.log(true, 'register device ' + settings.device);
                        sipcc.register(settings, function(error, session) {
                            if (error) { return cb(error); }
                            
                            logger.log(true, 'register success');
                            
                            // add listeners and callback client with registration info
                                
                            session.on('refer', function(request) {
                                logger.log(true, 'received REFER');
                                session.send(session.makeResponse(request, 200, 'OK'));
                            })
                            .on('subscribe', function(request) {
                                logger.log(true, 'received SUBSCRIBE');
                                session.send(session.makeResponse(request, 200, 'OK'));
                            })
                            .on('notify', function(request) {
                                logger.log(true, 'received NOTIFY');
                                session.send(session.makeResponse(request, 200, 'OK'));
                            })
                            .on('update', function(request) {
                                logger.log(true, 'received UPDATE');
                                session.send(session.makeResponse(request, 200, 'OK'));
                            })
                            .on('cancel', function(request) {
                                logger.log(true, 'received CANCEL');
                                session.send(session.makeResponse(request, 200, 'OK'));
                                socket.emit('conversationEnd', null, toConversation(request));
                            })
                            .on('invite', function(request) {
                                logger.log(true, 'received INVITE');
                                session.send(session.makeResponse(request, 100, 'Trying'));
                                
                                var ringing = session.makeResponse(request, 180, 'Ringing');
                                ringing.headers.to.params.tag = '000000000000000d2360afed-2e94aecf';
                                session.send(ringing);
                                socket.emit('conversationIncoming', null, toConversation(request));
                            });
                                
                            // client callback with successful registration info
                            cb(null, {
                                user: options.user ? options.user : null,
                                cucm: settings.cucm,
                                device: settings.device,
                                line: {
                                    number: settings.line,
                                    displayName: settings.displayName
                                }
                            });
                                
                            // optional
                            retrieveDialRules(settings.cucm);
                        }); // register
                    }); // retrieve device
			    } // ccmcip.getDevices success
			}); // ccmcip.getDevices
		}); // on registerPhone

		socket.on('startConversation', function(participant, cb) {
			logger.log(true, 'startConversation');
			
			var session = sipcc.session(socket.id);
				
			if (session) {
			    var dialstring = participant.recipient;
			    if (dialRules[session.config.cucm]) { 
			        dialstring = applyDialRules(dialstring, dialRules[session.config.cucm].application);
			    }
			    
				session.invite({ dialstring: dialstring }, function(error, response) {
					if (error) { return cb(error); }
					
					var conversation = toConversation(response);
					conversation.state = response.reason;
				
					if (cb) {
						// one-shot callback
						cb(null, conversation);
						cb = null;
					}
					else {
						// emit event for subsequent updates
						if (/Request Cancelled/i.test(response.reason)) {
							socket.emit('conversationEnd', null, conversation);
						}
						else {
							socket.emit('conversationUpdate', null, conversation);
						}
					}
				});
			}
			else {
			    cb({ message: 'no session found' });
			}
		}); // on startConversation
		
		socket.on('endConversation', function() {
			logger.log(true, 'endConversation');
			var divert = false;
			var conversation = {};
			var cb = null;
			
			if (typeof arguments[0] === 'boolean') {
				divert = arguments[0];
				conversation = arguments[1] || {};
				cb = arguments[2];
			}
			else {
				conversation = arguments[0] || {};
				cb = arguments[1];
			}
			
			var session = sipcc.session(socket.id);
				
			if (session) {
				if (divert) {
					session.refer({ callId: conversation.id }, function(error, response) {
						if (error) { return cb && cb(error); }
			
						if (response.status == 200) { cb && cb(null, toConversation(response)); }
					});
				}
				else {
					session.bye({ callId: conversation.id }, function(error, response) {
						if (error) { return cb && cb(error); }
			
						if (response.status == 200) { cb && cb(null, toConversation(response)); }
					});
				}
			}
			else {
			    cb({ message: 'no session found' });
			}
		});
	
		socket.on('unregisterPhone', function() {
			logger.log('unregisterPhone');
			
			var session = sipcc.session(socket.id);
				
			//if (session) { session.unregister(); }
			_reset();
		});
	
		socket.on('message', function(data) {
			logger.log('unknown message', data);
		}); // on message
	
		socket.on('disconnect', function() {
			logger.log(true, 'disconnection');
			
			_reset();
		}); // on disconnect
		
	}); // on connection
	
}

function retrieveDevice(cucm, device, callback) {
	// retrieve device configuration over HTTP
	var http = require('http');
	
	http.get({
		host: cucm,
		port: 6970,
		path: device + '.cnf.xml'
		},
		function(res) {
			var deviceXml = '';
		
			res
				.on('data', function(chunk) {
					deviceXml += chunk;
				})
				.on('close', function(errno) {
					logger.log('cannot retrieve device configuration (errno=' + errno + ')');
					callback({ error: errno });
				})
				.on('end', function() {
					logger.log(true, 'retrieveDevice response status ' + res.statusCode);
					
					if (res.statusCode != 200) {
						callback({ key: 'NoDevicesFound', message: 'cannot retrieve device' });
						return;
					}
					
					logger.log(true, 'retrieved ' + device  + ' device configuration');

					// parse XML device configuration
					deviceXml = deviceXml.replace(/(\r\n|\n|\r)/gm,"");

					var deviceInfo = {};
					var m = null;
					if (m = deviceXml.match(/<contact>(.*)<\/contact>/)) { deviceInfo.contact = m[1]; }
					if (m = deviceXml.match(/<displayName>(.*)<\/displayName>/i)) { deviceInfo.displayName = m[1]; }
					if (m = deviceXml.match(/<line.*<name>(\d+)<\/name>/m)) { deviceInfo.line = m[1]; }
					if (m = deviceXml.match(/<processNodeName><\/processNodeName>/i)) { deviceInfo.processNodeName = m[1]; }
					
					callback(null, deviceInfo);
				});
			});
}

function retrieveDialRules(cucm) {
	if (dialRules[cucm]) {
		logger.log('dial rules already available for cucm ' + cucm);
		return;
	}
	
	function _retrieve(path, array) {
		// retrieve dial rules configuration over HTTP
		var http = require('http');
		
		http.get({
			host: cucm,
			port: 6970,
			path: path
			},
		function(res) {
			var rulesXml = '';
		
			res
				.on('data', function(chunk) {
					rulesXml += chunk;
				})
				.on('close', function(errno) {
					logger.log('cannot retrieve ' + path + ' from cucm ' + cucm + '(errno=' + errno +')');
				})
				.on('end', function() {
					logger.log(true, 'retrieved ' + path + ' from cucm ' + cucm + ' response status ' + res.statusCode);
				
					if (res.statusCode != 200) { return; }
					
					var ruleRe = /DialRule\s+BeginsWith=\s*\"([\+\d]*)\"\s+NumDigits=\s*\"(\d*)\"\s+DigitsToRemove=\s*\"(\d*)\"\s+PrefixWith=\s*\"([\+\d]*)\"/ig;
					
					while (match = ruleRe.exec(rulesXml)) {
						array.push({
							beginsWith: match[1],
							numDigits: match[2] ? parseInt(match[2]) : 0,
							digitsToRemove: match[3] ? parseInt(match[3]) : 0,
							prefixWith: match[4] || ''
						});
					}
					
					logger.log(true, 'found ' + array.length + ' rules from ' + path + ' on cucm ' + cucm);
				});
			});
	}
	
	dialRules[cucm] = {
		application: [],
		directoryLookup: []
	};
	
	_retrieve('CUPC/AppDialRules.xml', dialRules[cucm].application);
	_retrieve('CUPC/DirLookupDialRules.xml', dialRules[cucm].directoryLookup);
}

// build a (simplified) conversation object from a sip message
function toConversation(msg) {
	//logger.log(true, 'toConversation');
	
	try {
		var participant = {};
		
		if (msg.headers['remote-party-id']) {
			// "Jing Jin" <sip:81384746@10.53.40.14>;party=calling;screen=yes;privacy=off
		
			var m = msg.headers['remote-party-id'].match(/("(.*?)")*.*<(.*)>/);
			
			if (m) {
				participant.name = m[2] || '';
				var remotePartyUri = sipcc.parseUri(m[3]);
				
				var number = remotePartyUri.user;
				
				// apply optional directory lookup dial rules
				var cucm = remotePartyUri.host;
				if (dialRules[cucm]) {
					number = applyDialRules(number, dialRules[cucm].directoryLookup);	
				}
				participant.recipient = number;
			}
		}	
	
		var conversation = {
			id: msg.headers['call-id'].substr(0, msg.headers['call-id'].indexOf('@')),
			participant: participant,
		}
	}
	catch(e) {
		logger.log('cannot build conversation: ' + e.message);
	}
	
	return conversation;
}

function applyDialRules(number, rules) {
    if (!util.isArray(rules)) { return number; }
    
    for (var i=0; i<rules.length; i++) {
	    var rule = rules[i];
						
		if (rule.beginsWith && number.indexOf(rule.beginsWith) != 0) { continue; }
					
		if (rule.numDigits && number.length != rule.numDigits) { continue; }
					
		number = rule.prefixWith + number.substr(rule.digitsToRemove, number.length);
		break;
	}

    return number;
}