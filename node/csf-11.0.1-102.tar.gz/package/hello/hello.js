
// hello CSF module

var logger = require('csf/logger').createLogger('hello');

exports.initialize = function(app, config) {
    
	logger.configure({
		verbose: config.verbose
	});
    
	app.get('/hello/view', function(req, res) {
		res.sendfile(__dirname + '/view.html');
	});
	
	app.get('/hello', function(req, res) {
	    logger.log(true, "GET /hello");
		res.send(reply("world"));
	});

	app.post('/hello', function(req, res) {
	    logger.log(true, "POST /hello from " + req.param('from'));
		res.send(reply(req.param('from')));
	});
};

function reply(from) {
	return "Hello " + from + " ! My name is Node.csf. It is exactly " + new Date().toLocaleString();
}
