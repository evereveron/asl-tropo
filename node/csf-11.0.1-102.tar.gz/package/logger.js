
function Logger(name, options) {
	this.name = name;
	
	// default settings
	this.settings = {
		enable: true,
		verbose: false,
		topic: '',
		log: require('util').log
	};
	
	this.configure(options);
	
	return this;
}

Logger.prototype.configure = function(options) {
	if (options) {
		if (typeof options.enable === "boolean") { this.settings.enable = options.enable; }
		if (typeof options.verbose === "boolean") { this.settings.verbose = options.verbose; }
		if (typeof options.topic === "string") { this.settings.topic = options.topic; }
		if (typeof options.log === "function") { this.settings.log = options.log; }
	}
	
	return this;
}

Logger.prototype.log = function() {
	if (this.settings.enable) {
		var isVerbose = typeof arguments[0] === "boolean" ? arguments[0] : false;
	
		if ((!isVerbose || (isVerbose && this.settings.verbose))) {
			var msg = typeof arguments[0] === "string" ? arguments[0] : arguments[1];
			var context = typeof arguments[1] === "object" ? arguments[1] : arguments[2];
	
			this.settings.log(this.name + ' - '
				+ (this.settings.topic ? '[' + this.settings.topic + ']' : '')
				+ msg, context);
		}
	}
	
	return this;
}

exports.Logger = Logger;

exports.createLogger = function(name, options) {	
	return new Logger(name, options);
}
