
module.exports = require('./quickcontact.js');
