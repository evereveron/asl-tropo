
var util = require('util');
var https = require('https');

function trim(str) {
	str = str || '';
	return str.replace(/^\s*/, '').replace(/\s*$/, '');
}

exports.getDevices = function(options) {

	options.log = options.log || util.log;

	var auth = options.userName + ':' + new Buffer(options.userPassword).toString('base64');

	var request = https.request({
		host: options.ccmcipHost,
		port: 8443,
		method: 'POST',
		path: '/ccmcip/Personalization',
		headers: {
			'host': options.ccmcipHost,
			'authorization': 'Basic ' + new Buffer(auth).toString('base64'),
			'content-type': 'text/xml'
		},
		rejectUnauthorized: options.rejectUnauthorized === false ? false : true
	},
	function (response) {

		options.log('ccmcipclient - response status=' + response.statusCode);
  
	    response.setEncoding('utf8');
  
  		if (response.statusCode != 200) {
  			options.error(response);
  			return;
  		}
	
		var body = "";
  
    	response.on('data', function (chunk) {
   			body += chunk;
   		});
    
	    response.on('end', function() {
   			//options.log('ccmcipclient - response body length=' + body.length);
   			//options.log(body);
    	
   			var devices = [];
    	
   			var matches = body.replace(/(\r\n|\n|\r)/gm,'').match(/<device>.*?<\/device>/gi) || [];
    	
	    	for (i=0; i<matches.length; i++) {
   				m = matches[i];

   				var name = /<name>(.*)<\/name>/i.exec(m)[1] || null;
    		
   				if (!name) {
   					options.log('ccmcipclient - no device name from "' + m + '"');
   				}
   				else {
   					devices.push({
   						name: trim(name),
    					description: trim(/<description>(.*)<\/description>/i.exec(m)[1]),
    					model: trim(/<model>(.*)<\/model>/i.exec(m)[1])
    				});
   				}
   			}
    	    options.log('ccmcipclient - found ' + devices.length + ' devices associated to user ' + options.userName);
   			options.success(devices);
   		});
   	});
   	
   	request.end('<getDevices><user>' + options.userName + '</user></getDevices>');
    
}; // get Devices
