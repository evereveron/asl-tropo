
module.exports = require('./phoneconfig.js');
